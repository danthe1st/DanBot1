---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|                                                                                       DanBot1                                                                                       |
|                                                                                      3.1 final                                                                                      |
|                                                                                   by Daniel Schmid                                                                                  |
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 

- go to the Website https://discordapp.com/developers/applications/me
- click "new App"
- type the name of the App
- [OPTIONAL] select a description and an Icon
- click "create App"
- scroll to "Bot"
- click "create a Bot user"
- click "Yes, do it"
- invite the Bot to Servers:(you can do this later too.)
	- scroll to "OAUTH2 URL GENERATOR"
	- click "Generate OAuth2 URL"
	- select "Bot" and "Administrator"
	- give the URL to an Administrator of the Discord Server you want to join the Bot
	 When the Administrator uses the URL he has to select a Server where the Bot is running and click "authorise"
	 then the needs to solve a reCAPTCHA and the Bot is invited
 a menu bar should appear
- in this menu bar click "click to reveal" beside of "Token:"
 than a code should appear
 DO NOT SHARE THIS TOKEN TO OTHERS!!!
 with this code you can access your Bot.
- copy this token
- Extract this zip-File(if you haven't done this yet)
- If you want to get the latest version of the Bot run Updater.jar
if you are using Windows:
	- edit the DanBot1.bat
		- paste your token after "token="
	- run the Bot with the DanBot1.bat
if you are using Linux or Apple OS:
	- edit the DanBot1.sh
		- paste your token after "token="
	- run the Bot with the DanBot1.sh
	
	
Program arguments:
	you can customize DanBot1 a bit with adding arguments.
	to use these you can simply add this in the DanBot1.bat or DanBot1.sh script.
	You can enter following arguments:
	* help				...	lists all arguments
	* nostop			...	disables the stop and the restart command
	* game=<game>		...	sets the Bot playing a specified game(instead of <game> you should write the name of the game with underscores instead of spaces)
	* admin=<id>		...	set the Bot admin to a specified user(you need to put the the ID(ISnowfake ID) of the admin instead of <id>, the admin can bypass the permission System)
	* status=<status>	...	Sets a Discord-Status for the Bot(instead of <status> you should write either donotdisturb or idle or invisible or online or offline or unknown)
	
Installing Plugins:
- when running the Bot for the first time it will create a Directory plugins in a Directory named SERVER_SETTINGS.
- You can install plugins by copying the .jar File of the Plugin in this Directory
- You may only install Plugins made specifically for DanBot1.