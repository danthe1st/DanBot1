#                DanBot1                #
#           by Daniel Schmid            #

java -jar /home/pi/DanBot1.jar token=